from .info import info
from .lib import Lib

lib = Lib()