from .compiler import Compiler

compiler = Compiler()